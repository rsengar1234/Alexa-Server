//import { response } from 'express';
//import {modifyDynamoDBTable} from './add_cred';

function navigateToDifferentRoute() {
    window.location.href = "/privacy.html"; // Change this to your desired URL
}

function getinputvalue(){
    const userElement = document.getElementById('username');
    const userName = userElement.value;
    console.log(userName);
    const passElement = document.getElementById('password');
    const passWord = passElement.value;
    console.log(passWord);

    //const userName = "rohsengar@gmail.com";
    //const passWord = "123";
    /*
    const url = "https://5odknxrvbf.execute-api.ap-south-1.amazonaws.com/auth_code/validate_cred";
    const data = {useremail:userName,
                   password:passWord}
    
    fetch(url,{method:"POST",headers:{'Content-Type':'application/json'},body:JSON.stringify(data)})
    .then(response=>response.json())
    .then(data=>{
        console.log(data);
        //alert('Add Successful');
    })
        */
           
}
